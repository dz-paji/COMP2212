'auto' is a bash script. 
You can run it on uglogin.ecs.soton.ac.uk if you do not use a *nix system. 

To use:
Put your compiled interpreter called “Tsl” in the automarker directory.
Put your solution prN.tsl in the subdirectory prN/  for N = 1 to 5
Run ./auto whilst in the automarker directory.

To add further tests:
For each new test, put the input tile files in a subdirectory called inputN in subdirectory prN/inputs/
And put the expected output data in a file called expN.tl in subdirectory prN/expected/
